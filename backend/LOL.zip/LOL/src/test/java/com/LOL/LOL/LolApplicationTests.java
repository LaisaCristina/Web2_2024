package com.LOL.LOL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LolApplicationTests {

	@Test
	void contextLoads() {
	}

}
